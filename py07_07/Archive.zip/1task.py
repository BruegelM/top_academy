# сделать 1 и 3 задачу

# str[X:Y:Z]
# где X - начало среза, Y - конец среза, Z - шаг среза
# S - шаг среза
tmp = "А буду я у дуба".lower()
print("".join(tmp.split(' ')))
print(tmp)
print(tmp[::-1])
print(tmp==tmp[::-1])


