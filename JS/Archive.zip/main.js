// var/let - var устарело, теперь let - ключевая лексема объявляющая лексема. 
// let a = 5 - объявление переменной с именем а и значением 5
// const - константа, неизменяемая переменная. 
// const a = 5 - объявление константы с именем а и значением 5
//function foo() - функция с именем changeColor и телом функции. Foo типичный пример функции. 
// сооздание функции начинается с ключевой function, далее пишется название функции и заканчивается с фигурной скобкой.

//сочетание DOM дерева и скриптов

//event - объект хранящий в себе информацию о произашедшем событии 

//События
    // События загрузки     
    //      1) DOMcontentLoaded - срабатывает когда загружен и разобран HTML документ без ожидания css и изображения document.add.EventListener('DOMContentLoaded', function() {
    //      2) Load - срабатывает когда все ресурсы и документ загружен
    //События взаимодействия
    //      1) click/doubleclick - срабатывает когда кнопка нажата
    //      2) keydown/keyup - срабатывает когда клавиша нажата/отпущена
    //Событие изменения
    //      1) change - срабатывает когда значение изменяется
    //      2) input - срабатывает когда значение вводится


// Событие щелчка на любой элемент. В event по-умолчанию хранится информация какой кнопкой кликнул и куда ВАЖНО: найти и почитать какую информацию там храним
//     document.addEventListener('click', function(event) {
//         alert('Кликнул на элемент:' + event.target.localName);
//         console.log(event.target);
//     })


//     document.addEventListener('DomContentLoaded', function() {
//         alert('document.addEventListener DomContentLoaded')
//     })
    
//     //сочетание документов и загруженных ресурсов
//     window.addEventListener('load', function() {
//         alert('window.addEventListener load')
//     })
    
//     //событие изменено поля ввода формы
//     document.addEventListner('change', function(event){
//         if(EventTarget.tagName == 'INPUT') {
//             console.log('Изменено значение:', event.target.value);
//         }
//     })





// //хер знает зачем, надо разобраться
// const cButton = document.getElementById('color_button');
// cButton.addEventListener('click', clickButton);

//     // на самом деле просто алерт что кнопка нажата, цвет не меняюет 
//     function clickButton() {
//         alert('function clickButton')
    
//     }
    

// //меняем цвет текста на красный
// document.getElementById('color_button').addEventListener('click', function() {
//     const heading = document.querySelector('h1');
//     heading.style.color = heading.style.color === 'red' ? 'blue': 'red';
// })

const form = document.getElementById('regForm');
form.addEventListener('submit', function(event) {
    event.preventDefault(); // Отключаем стандартную обработку событий формы
    
    // Собираем данные формы
    const formData = new FormData(form);
    
    // Получаем значения всех полей
    const username = formData.get('login');
    const email = formData.get('email');
    const password = formData.get('password');
    const phone = formData.get('tel');
    const birthDate = formData.get('date');
    const agreement = form.querySelector('.checkbox').checked;
    
    // Выводим в консоль для проверки
    console.log('Форма отправлена!');
    console.log('Логин:', username);
    console.log('Email:', email);
    console.log('Пароль:', password); // В реальном проекте пароль не следует логировать!
    console.log('Телефон:', phone);
    console.log('Дата рождения:', birthDate);
    console.log('Согласие на обработку:', agreement ? 'Да' : 'Нет');
    
    // Здесь можно добавить валидацию данных перед отправкой
    if (!validateForm(username, email, password, phone, birthDate, agreement)) {
        return; // Если валидация не пройдена, прерываем выполнение
    }
    
    // Дальнейшая обработка (например, отправка на сервер)
    // sendFormData(formData);
});

// Функция для базовой валидации формы
function validateForm(username, email, password, phone, date, agreement) {
    if (!username || !email || !password || !phone || !date) {
        console.error('Все поля обязательны для заполнения!');
        return false;
    }
    
    return true; // Все проверки пройдены
}
